package com.example.android11lesson6dz

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.android11lesson6dz.`interface`.OnItemTextListener
import com.example.android11lesson6dz.data.TextModel
import com.example.android1lesson6dz.R
import com.example.android1lesson6dz.databinding.FragmentFirstBinding
import com.example.android1lesson6dz.databinding.ItmeTextBinding

class TextAdapter(
    private val listText: MutableList<TextModel>,
    private val onItemTextListener: OnItemTextListener
) :
    RecyclerView.Adapter<TextAdapter.TextViewHolder>() {
    private lateinit var binding: ItmeTextBinding

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextViewHolder {
        return TextViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.itme_text, parent, false)
        )
    }

    override fun onBindViewHolder(holder: TextViewHolder, position: Int) {
        holder.onBind(listText[position])
    }

    inner class TextViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun onBind(textModel: TextModel) {
            binding.textMain.text = textModel.text
            itemView.setOnClickListener {
                onItemTextListener.onClick(textModel)
            }
        }
    }
    override fun getItemCount(): Int = listText.size
}