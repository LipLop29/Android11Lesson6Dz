package com.example.android11lesson6dz.`interface`

import com.example.android11lesson6dz.data.TextModel

interface OnItemTextListener {
    fun onClick(model : TextModel)
}