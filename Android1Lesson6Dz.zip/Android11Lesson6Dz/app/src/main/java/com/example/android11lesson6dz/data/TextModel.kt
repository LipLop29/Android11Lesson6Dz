package com.example.android11lesson6dz.data

data class TextModel(val text: String) : java.io.Serializable
